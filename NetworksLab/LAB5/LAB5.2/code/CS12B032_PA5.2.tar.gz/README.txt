script contains plot.py script for ploat graph
code contaings all the code graphs and data for all the exp-n
