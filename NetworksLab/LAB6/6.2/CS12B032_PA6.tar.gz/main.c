#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <math.h>

int node_id=-1;
char *inFile=NULL,*outFile=NULL;
int HELLO_INTERVAL=1;
int LSA_INTERVAL=0;
int SPF_INTERVAL=0;

//typedef struct edge edges;
struct edge
{
    int node1;
    int node2;
    int wt1;
    int wt2;	
}edges;
void parse_command(int argc,char**argv){
	int i=0;
    for (i=1;i<argc;i++){
    	switch(argv[i][1]){
    		case 'i':
    		    if(++i <= argc)
    		    	node_id=atoi(argv[i]);
    		    break;

    		case 'f':
    		    if(++i <=argc)
    		    	inFile=argv[i];
    		    break;

    		case 'o':
    		    if(++i <=argc)
    		    	outFile=argv[i];
    		    break;

    		case 'h':
    		    if(++i <= argc)
    		    	HELLO_INTERVAL=atoi(argv[i]);
    		    break;

    		case 'a':
    		    if(++i <= argc)
    		    	LSA_INTERVAL=atoi(argv[i]);
    		    break;

    		case 's':
    		    if (++i <= argc)
    		    	SPF_INTERVAL=atoi(argv[i]);
    		    break;

    		default:
    		    break;
    	}
    }        
}
int main(int argc,char**argv){
     parse_command(argc,argv);
     /*printf("inFile: %s, outFile: %s\n",inFile,outFile);
     printf("node_id: %d , HELLO_INTERVAL: %d , LSA_INTERVAL: %d , SPF_INTERVAL: %d\n",
     	        node_id,HELLO_INTERVAL,LSA_INTERVAL,SPF_INTERVAL);*/
    int N_nodes,N_edges;
    FILE*fp=fopen(inFile,"r");
    char string[50];
    while(fgets(string,49,fp)!=NULL){

    }
    return 0;
}