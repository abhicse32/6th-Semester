read_from=open("data.txt","r")
write_to="combined2.txt"
with open(write_to,"w") as fout_:
	for lines in read_from:
		if lines[0]!='@':
			lines=lines[4:]
		fout_.write(lines)
