__author__ = 'abhishek'

import networkx as nx
import numpy as np
from numpy import linalg as LA
import sys
from sklearn.cluster import KMeans
import networkx as nx

#reading the data from the file
def read_datset():
    filename=sys.argv[1]
    file_=open(filename,"r")
    edges,nodes=[],[]
    for lines in file_:
        temp=[int(val)-1 for val in lines.split()[:2]]
        edges.append(tuple(temp))
        if temp[0] not in nodes:
            nodes.append(temp[0])
        if temp[1] not in nodes:
            nodes.append(temp[1])
    file_.close()
    nodes.sort()
    return nodes[len(nodes)-1]+1,edges

def create_adjacency(n,edges):
    A=[[0 for val in range(n)] for vals in range(n)]
    degree_count={}
    for edge in edges:
        A[edge[0]][edge[1]]=1
        A[edge[1]][edge[0]]=1
        if edge[0] in degree_count:
            degree_count[edge[0]]+=1
        else:
            degree_count[edge[0]]=1
        if edge[1] in degree_count:
            degree_count[edge[1]]+=1
        else:
            degree_count[edge[1]]=1

    return A,degree_count

def degree_vector(n,m,degree_count,A):
    d=[[0] for val in range(n)]
    for nodes in degree_count:
        d[nodes][0]=degree_count[nodes]
    d=np.array(d)
    dT=d.T
    d_dot_dT=np.dot(d,dT)
    d_dot_dT=d_dot_dT/(2.0*m)
    B=np.subtract(A,d_dot_dT)
    return B

def ground_truth(filename):
    file_=open(filename,"r")
    count,labels=0,{}
    for lines in file_:
        labels[count]=int(lines)
    file_.close()
    return labels

def top_k_eigen_vectors(A):
    eig_val,eig_vecotr=LA.eig(np.array(A))
    sorted_eig_vals=[[eig_val[i],i] for i in range(len(eig_val))]
    sorted_eig_vals=sorted(sorted_eig_vals,key=lambda x:x[0],reverse=True)
    top_k_values=sorted_eig_vals[:5]
    top_k_vectors=[list(eig_vecotr[vals[1]]) for vals in top_k_values]
    return top_k_vectors

def find_clusters(top_k):
    top_k=np.array(top_k)
    top_k=top_k.T
    k_means=KMeans(5)
    k_means.fit(top_k)
    Z=k_means.predict(top_k)
    return Z

def create_graph(edges):
    G=nx.Graph()
    G.add_nodes_from([val for val in range(419)])
    G.add_edges_from(edges)
    return G


n,edges=read_datset()
A,degree_count=create_adjacency(n,edges)
labels=ground_truth(sys.argv[2])
m=len(edges)
B=degree_vector(n,m,degree_count,A)
top_k=top_k_eigen_vectors(B)
Z=find_clusters(top_k)
G=create_graph(edges)
L=nx.normalized_laplacian_matrix(G)
#print purity(Z,labels)
