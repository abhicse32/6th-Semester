__author__ = 'abhishek'

import networkx as nx

def best_betweenness(G_):
    dict_betweenness=nx.edge_betweenness_centrality(G_)
    items_list=dict_betweenness.items()
    items_list.sort(key=lambda x:x[1],reverse=True)
    return  items_list[0][0]

def count_components(component):
    count=0
    for comps in component:
        count+=1
    return count



def Girwan_Newman(G):
    #checks if the graph component or the graph
    # itself has 1 node and returns the same
    if G.number_of_nodes()==1:
        return G.nodes()
    components=nx.number_connected_components(G)

    while count_components(components)==1:
        G.remove_edge(find_best_edge(G))
        components=nx.connected_component_subgraphs(G)
    result=[c.nodes() for c in components]
    for c in Components:
        result.extend(Girwan_Newman(c))
    return result