import networkx as nx
file_=open("combined.txt","r")
lst=["John Augustine","Shankar Balachandran","Sutanu Chakraborti",
     "C. Chandra Sekhar","Sukhendu Das","T. A. Gonsalves","D. Janakiram",
     "V. Kamakoti","Deepak Khemani","P. Sreenivasa Kumar",
     "Rajsekar Manokaran","Chester Rebeiro","Anurag Mittal",
     "Hema A. Murthy","C. Siva Ram Murthy","Madhu Mutyam",
     "V. Krishna Nandivada","Meghana Nasre","Rupesh Nasre",
     "N. S. Narayanaswamy","S. V. Raghavan","C. Pandu Rangan",
     "Sayan Ranu","B. V. Raghavendra Rao","B. Ravindran",
     "Jayalal Sarma","Krishna M. Sivalingam"]
edges=[]
for line in file_:
	coauthors=line.split(",")
	dep_prof=""
	coauthors[-1]=coauthors[-1][:-1]
	for authors in coauthors:
		if authors in lst:
			dep_prof=authors
			break
	for authors in coauthors:
		if authors!=dep_prof:
			edges.append((dep_prof,authors))

G=nx.Graph()
G.add_edges_from(edges)
lst=G.nodes()
print lst.count('')
# number of connected components
print "1. number of connected components: %d"%nx.number_connected_components(G)

#finding the diameters of the connected components
sub_graph_list=nx.connected_component_subgraphs(G)
print "2. diameters of the connected components are:",
for graph in sub_graph_list:
	print nx.diameter(graph,e=None),

degree_list=nx.degree(G)
print degree_list